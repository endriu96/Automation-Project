package TestDefinitions;
import PageObjects.AlgoPage;
import PageObjects.GeneralPage;
import PageObjects.UniversalObjects;
import org.openqa.selenium.WebDriver;

public class GeneralActions  extends AlgoPage {
	private GeneralPage onTheDashboard;
	private UniversalObjects inTheMenu;

	public GeneralActions(WebDriver driver) {
		super(driver);
		onTheDashboard = new GeneralPage(driver);
		inTheMenu = new UniversalObjects(driver);
	}

	public void addNewBoxes() { //expand for all box types
		inTheMenu.createDashboardAndMoveToIt("addNewBoxes");

		onTheDashboard.removeAllBoxes();
		onTheDashboard.addActiveOrdersBox();
		onTheDashboard.addMarketWatchBox("NEOBTC@BINANCE");
		onTheDashboard.addOrderBookBox("NEOBTC@BINANCE");
		onTheDashboard.addActiveStrategiesBox();
		onTheDashboard.addStrategiesBox("ProbabilisticOrderBookVerifier");


	}
}
