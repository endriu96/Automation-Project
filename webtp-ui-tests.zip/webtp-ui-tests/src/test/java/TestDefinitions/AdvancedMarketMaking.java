package TestDefinitions;
import PageObjects.AlgoPage;
import PageObjects.StrategyPopUps.AdvancedMarketMakingPopUp;
import PageObjects.UniversalObjects;
import org.openqa.selenium.WebDriver;

public class AdvancedMarketMaking  extends AlgoPage {
	private UniversalObjects inTheMenu;
	private AdvancedMarketMakingPopUp ammPopUp;

	public AdvancedMarketMaking(WebDriver driver) {
		super(driver);
		inTheMenu=new UniversalObjects(driver);
		ammPopUp = new AdvancedMarketMakingPopUp(driver);
	}
	public void runAMM() throws InterruptedException { //template for all tests - fill the space in between
		inTheMenu.createDashboardAndMoveToIt("runAMM");
		inTheMenu.runStrategiesInputTextAddFirstElement();
		ammPopUp.fillRequiredAmmParameters("eth-pln@bitbay","0.005","3000",
				"10000","0.01","0.01");
		ammPopUp.runStrategy();
		//Wlacz box strategies(AMM)
		//Wlacz strategie (kliknij "prepare the strategy" w boxie, wypelnij wymagane pola, klinij run i zamknij popup)
		//Upewnij sie, ze strategia pojawila sie w odpowiednich boxach (Strategies > AMM i Active Strategies)
		//Wylacz strategie


	}



}
