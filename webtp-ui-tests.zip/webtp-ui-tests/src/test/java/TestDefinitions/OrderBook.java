package TestDefinitions;
import PageObjects.AlgoPage;
import PageObjects.UniversalObjects;
import org.openqa.selenium.WebDriver;

public class OrderBook  extends AlgoPage {
	private UniversalObjects inTheMenu;
	public OrderBook(WebDriver driver) {
		super(driver);
		inTheMenu= new UniversalObjects(driver);
	}

	public void addAndRemoveOrder() {
		inTheMenu.createDashboardAndMoveToIt("addAndRemoveOrder");
		//Set desired instrument
		//Switch to classic view
		//decrease precision
		//make sure you are centered
		//send an order in a safe distance
		//verify the presence of this order
		//remove this order
	}
}
