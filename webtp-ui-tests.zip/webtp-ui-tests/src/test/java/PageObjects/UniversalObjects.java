package PageObjects;


import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class UniversalObjects extends AlgoPage {
    private WebDriver obj;

    private static final String DEFAULTWORKSPACE = "Default Workspace";
    //left top to bottom
    private static final By version = new By.ByCssSelector("span[class=system__version]");

    //top left to right
    private static final By logo = new By.ByCssSelector("img[alt=logo]");
    private static final By dashboard = new By.ByCssSelector("span[aria-label=appstore]");
    private static final By marketMaking = new By.ByCssSelector("span[aria-label=sketch]");
    private static final By avatar = new By.ByCssSelector(".ant-avatar");
    private static final By stop = new By.ByCssSelector("span[aria-label=stop]");
    private static final By workspaces = new By.ByCssSelector("span[aria-label=windows]");
    private static final By workspacesAreOpen = new By.ByXPath("//button[contains(@class, 'ant-dropdown-open')]/" +
            "span[contains(@aria-label, 'windows')]");
    private static final By settings = new By.ByCssSelector("span[aria-label=setting]");
    private static final By logout = new By.ByCssSelector("span[aria-label=logout]");
    private final By addWorkspace = new By.ByXPath("//div[contains(@class, 'WorkspacesManagerstyled__Wrapper')] " +
            "//span[text() = 'Add workspace']");
    private final By newWorkspaceName = new By.ByXPath("//input [contains (@placeholder, 'Workspace name')]");
    private final By confirmNewWorkspace = new By.ByXPath("//input [contains (@placeholder, 'Workspace name')]" +
            "/../../div/button/span[text()='OK']");
    private final By cancelNewWorkspace = new By.ByXPath("//input [contains (@placeholder, 'Workspace name')]" +
            "/../../div/button/span[text()='Cancel']");
    private final String workspaceByNameRoot = "//div[contains(@class, 'WorkspacesManagerstyled__Wrapper')] //div[text() = '";
    private final By confirmWorkspaceRemoval = new By.ByXPath("//div[contains(@class, 'WorkspacesManagerstyled__Wrapper')] " +
            "//div[text() = 'addAndMoveToDashboard']/..//button/span");
    private final By removeNonActiveWorkspace = new By.ByXPath("//div[contains(@class,'WorkspacesManagerstyled__MenuItemInner')]"
            + "//button[not(@disabled)]");
    private final By workspaceLabel = new By.ByXPath("//div[contains(@class,'WorkspacesManagerstyled__MenuItemInner')]"
            + "/div");

    private final By runStrategies = new By.ByCssSelector("#sidebar span[aria-label=play-circle]");
    private final By strategyListInput = new By.ByCssSelector("#sidebar input");
    private final By strategyFirstElement = new By.ByCssSelector("#sidebar div[data-testid=list] div:nth-child(1)");
//Zrobić metodę ,,kliknij run strategies i wpisz w Strategy Input zadany text i kliknij pierwszy element"
    public UniversalObjects(WebDriver driver){
        super(driver);
    }

    public void runStrategiesInputTextAddFirstElement(){
        click(runStrategies);
       // click(strategyListInput);
        writeStrategyName("Advanced");
        click(strategyFirstElement);
        waitForTheAnimationToEnd();

    }
    public void writeStrategyName (String strategyName){
        typeIn(strategyName, strategyListInput);

    }


    public void checkPresenceOfUniversallyPresentObjects() {
        isPresent (version);
        isPresent (settings);
        isPresent (logout);
    }
    public void logout(){
        click(logout);

    }
    public void createDashboardAndMoveToIt(String name){
        addWorkspace(name);
        switchToWorkspace(name);
    }

    public void makeSureDefaultWorkspaceExists(){
        makeSureWorkspacesAreOpen();

        if (!isPresent(new By.ByXPath(workspaceByNameRoot + DEFAULTWORKSPACE + "']")))
        addWorkspace(DEFAULTWORKSPACE);
        if (driver.findElement(new By.ByXPath("//div[contains(@class,'WorkspacesManagerstyled__Wrapper')]")).isDisplayed()){
            driver.findElement(workspaces).click();
        }
        waitUntilThePageIsLoaded();

    }
    public void removeWorkspace(String name){

        makeSureWorkspacesAreOpen();
        while (driver.findElements(new By.ByXPath(workspaceByNameRoot + name + "']")).size()>0)
        {
            click(workspaceRemovalByName(name));
            waitForTheAnimationToEnd();
        }
    }
    public void removeNonActiveWorkspaces(){//tooltip workspaces czasami zaslania kasowanie workspace'ow trzeba to lepiej ogarnac
        makeSureWorkspacesAreOpen();        //bo teraz zdarza sie to okazjonalnie
        while (driver.findElements(removeNonActiveWorkspace).size()>0)
        {
            click(workspaceLabel);
            waitForTheAnimationToEnd();
            click(removeNonActiveWorkspace);
            waitForTheAnimationToEnd();
        }
    }
    public void switchToDefaultWorkspace(){
        switchToWorkspace(DEFAULTWORKSPACE);}

    public void switchToWorkspace(String name){
        makeSureWorkspacesAreOpen();
        hoverOver(marketMaking);
        click(switchToWorkspaceByName(name));
        waitUntilThePageReloads();
    }
    private void present(By what){
        Assertions.assertTrue(!driver.findElements(what).isEmpty());
    }

    public void addWorkspace(String name){
        waitFor(addWorkspace);
        if (driver.findElement(addWorkspace).isDisplayed())
        {
            System.out.println("Workspaces are visible");
        }
        else
        {
            System.out.println("Workspaces are not visible");
            driver.findElement(workspaces).click();
        }
        makeSureWorkspacesAreOpen();
        click(addWorkspace); //Moze nie zdazyc schowac okienka dodawania workspace'ow
        waitUntilThePageIsLoaded();
        typeIn(name, newWorkspaceName);
        driver.findElement(confirmNewWorkspace).click();
    }
    //////////////////////////////////////// Custom By's section
    private By removeWorkspaceByName(String name){
        return new By.ByXPath(workspaceByNameRoot + name + "']/..//button");}
    private By switchToWorkspaceByName(String name){
        return new By.ByXPath(workspaceByNameRoot + name + "']/..//span[contains (@aria-label, 'home')]");}

    private void waitUntilThePageIsLoaded (){
        int maxWait=3000;
        while (driver.findElements(workspaces).size()<1 && maxWait >0)
        {
        try {Thread.sleep(100);}  catch (InterruptedException e) {
                e.printStackTrace();
            }
        maxWait-=100;
        }
    }
    private void waitUntilThePageReloads(){
        try {Thread.sleep(1000);}  catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    private void waitForTheAnimationToEnd(){
        try {Thread.sleep(100);}  catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private By workspaceRemovalByName(String name){
        return new By.ByXPath("//div[contains(@class, 'WorkspacesManagerstyled__Wrapper')] " +
                "//div[text() = '"+name+"']/..//button/span");
    }

    private void makeSureWorkspacesAreOpen()
    {
        waitFor(workspaces);
        if (!isPresent(workspacesAreOpen))
            click(workspaces);
    }



}
