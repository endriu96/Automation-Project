package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//this is a stub
public class MarketMakingPage {
    private WebDriver driver;
    private static final By logo = new By.ByCssSelector("img[alt=logo]");
    private static final By instrumentSelector =
            new By.ByCssSelector("div[class*=MarketMakingstyled__Header] div[class*=InstrumentsSelectorButton]");
    private static final By columnSelector =
            new By.ByCssSelector("div[class*=MarketMakingstyled__Header] div[class*=TableColumnsSelectors]");
    //
    private static final By actions = new By.ByCssSelector("div[title=ACTIONS]");
    
    MarketMakingPage(WebDriver drv){
        driver=drv;
    }

}
