package PageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class GeneralPage extends AlgoPage{
    private WebDriver driver;

    private static final By genericCloseBox = new By.ByCssSelector("header[class*=GridBox] span[aria-label=\"close\"]");
    private static final By addABox = new By.ByCssSelector("span[aria-label=\"plus\"]");
    private final By strategiesHeader = headerByText("Strategies");
    private final By orderBookHeader = headerByText("Order book");
    private final By marketWatchHeader = headerByText("Market watch");
    private final By activeStrategiesHeader = headerByText("Active strategies");
    private final By setContent = headerByText("Set content");
    private final By marketWatchItem = itemByText("Market watch");
    private final By strategiesItem = itemByText("Strategies");
    private final By activeStrategiesItem = itemByText("Active strategies");
    private final By activeOrdersItem = itemByText("Active orders");
    private final By orderBookItem = itemByText("Order book");

    private final By instrumentInput = new By.ByXPath("//input[contains(@class,'ant-input')]" +
            "[contains(@placeholder,'Search by instrument name')]");
    private final By closeOrderBookTab = new By.ByXPath(
            "//div[contains(@class,'GridBoxstyled__Title')][contains(text(),'Order Book')]/../..//" +
                    "div[contains(@data-testid,'close')]");
    private final By popupConfirmation = new By.ByXPath("//div[contains(@class,'confirm')]/" +
            "/button/span[contains(text(),'Yes')]");
    private final By addTabSelector = new By.ByXPath(
            "//div[contains(@class,'GridBoxstyled__Title')][contains(text(),'Order Book')]/../../" +
                    "div//div[contains(@class,'AddTab')]/button");
    private final By selectInstrumentForOrderBook = new By.ByXPath("");

    public GeneralPage(WebDriver driver){
        super(driver);
        this.driver =driver;
    }
    //Clicking on X in the top right corner of the box cleans its content if there was any
    //If box had no content (it was not set as Order Book, Strategies etc.) it closes the box
    public void removeAllBoxes(){
        waitFor(genericCloseBox);
        while (driver.findElements(genericCloseBox).size()>0){
            System.out.println("Boxes countdown: "+driver.findElements(genericCloseBox).size());
            driver.findElement(genericCloseBox).click();
        }
    }
    public void addABox(){
        driver.findElement(addABox).click();
        try {Thread.sleep(500);}  catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void addMarketWatchBox(String instrumentName){
        addNewInstrumentBox (instrumentName, marketWatchItem);
    }
    public void addOrderBookBox(String instrumentName){
        addNewInstrumentBox (instrumentName, orderBookItem);
    }
    public void addStrategiesBox(String strategyName){
        addGeneralBox(strategiesItem);
        driver.findElement(instrumentByText(strategyName)).click();
    }
    public void addActiveOrdersBox(){addGeneralBox(activeOrdersItem);}
    public void addActiveStrategiesBox(){addGeneralBox(activeStrategiesItem);}

    private void addNewInstrumentBox (String instrumentName, By boxType){
        addGeneralBox(boxType);
        driver.findElement(instrumentInput).sendKeys(instrumentName);
        shortWait();
        driver.findElement(instrumentByText(instrumentName)).click();
    }
    private void addGeneralBox(By boxType){
        addABox();
        shortWait();
        driver.findElement(setContent).click();
        shortWait();
        driver.findElement(boxType).click();
    }
    private void setOrderBookForInstrument(String instrument){
        driver.findElement(orderBookHeader).click();
        driver.findElement(orderBookItem).click();
    }

    private By headerByText(String text){
        return new By.ByXPath("//div[contains(@class,'GridBoxstyled__Title')][contains(text(),'"+text+"')]");
    }
    private By itemByText(String text){
        return new By.ByXPath("//li[contains(@class,'ant-menu-item')][contains(text(),'"+text+"')]");
    }
    private By instrumentByText(String text){
        return new By.ByXPath("//li[contains(@class,'ant-list-item')][contains(text(),'"+text+"')]");
    }
    private void shortWait(){
        try {Thread.sleep(200);}  catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
