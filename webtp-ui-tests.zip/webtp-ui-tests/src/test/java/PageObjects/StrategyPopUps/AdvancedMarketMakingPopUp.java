package PageObjects.StrategyPopUps;

import PageObjects.AlgoPage;
import PageObjects.InstrumentPicker;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AdvancedMarketMakingPopUp extends AlgoPage {

    InstrumentPicker instrumentPicker ;

    private static final By strategyTitle = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]");
    private static final By instrumentInput = new By.ByXPath("//div[@class='window-content']//" +
            "button[contains(text(),'Select instruments')]");
    private static final By orderSizeInput = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id=\"ORDER_SIZE\"]");
    private static final By delayAfterTradeInput = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id=\"DELAY_TRADE\"]");
    private static final By delayAfterRejectInput = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id=\"DELAY_REJECT\"]");
    private static final By openPositionLimitInput = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id=\"OPEN_POSITION_LIMIT\"]");
    private static final By openPositionLimitDefensiveModeInput = new By.ByXPath("//header" +
            "[@class='window-header']//div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]" +
            "/../..//input[@id='DEFENSIVE_OPEN_POSITION_LIMIT']");
    private static final By confirmButton = new By.ByXPath("//header[@class='window-header']//" +
            "div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//button[@type=\"submit\"]");

    public AdvancedMarketMakingPopUp(WebDriver driver) {
        super(driver);
        instrumentPicker = new InstrumentPicker(driver);
    }

    public void fillRequiredAmmParameters(String instrument, String orderSize, String delayAfterTrade,
                                          String delayAfterReject, String openPositionLimit, String openPositionLimitDefensiveMode ) throws InterruptedException {
        click(instrumentInput);
        instrumentPicker.chooseInstrument(instrument);
        instrumentPicker.confirm();
        typeIn(orderSize,orderSizeInput);
        typeIn(delayAfterTrade,delayAfterTradeInput);
        typeIn(delayAfterReject,delayAfterRejectInput);
        typeIn(openPositionLimit,openPositionLimitInput);
        typeIn(openPositionLimitDefensiveMode,openPositionLimitDefensiveModeInput);

    }


    public void runStrategy(){
        click(confirmButton);
    }

    /* Weryfikacja(metoda) czy jesteśmy w Headerze MarketMaking




//Znalezienie pola Open Position Limit
//header[@class='window-header']//div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id="OPEN_POSITION_LIMIT"]


//Znalezienie pola OPL defensive mode
//header[@class='window-header']//div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//input[@id="DEFENSIVE_OPEN_POSITION_LIMIT"]


//header[@class='window-header']//div[contains (@class, 'title')][contains(text(),'AdvancedMarketMaking')]/../..//button[@type="submit"]

//Stworz metodę która przyjmie parametry AMM i drugą która je uruchomi
     */
}
