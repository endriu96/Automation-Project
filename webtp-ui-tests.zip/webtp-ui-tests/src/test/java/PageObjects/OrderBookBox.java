package PageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class OrderBookBox extends AlgoPage {
	private static final String orderBookInXpath = "//div[contains(@class,'GridBoxstyled__Title')][contains(text(),'Order Book')]/../..//";
	private static final By addTab = new By.ByXPath(orderBookInXpath + "div[contains(@class,'AddTabButton')]/button");
	private static final By closeTab = new By.ByXPath(orderBookInXpath + "div[contains(@data-testid,'close')]");
	private static final By confirmTabRemoval = new By.ByXPath("//span[contains(@class,'ant-modal-confirm-title')]" +
			"[contains(text(),'Do you want to remove tab?')]/../..//button/span[contains(text(),'Yes')]");
	private final By selectInstrumentInOrderBook = new By.ByXPath("//div[contains(text(),'Order Book')]/../" +
			"..//button[contains(text(),'Select instrument')]");
	private static final String selectInstrument = "//div[contains(@class,'title')][contains(text(),'Select instrument')]/../..//";
	private static final By instrumentsSearchInput = new By.ByXPath(selectInstrument +
			"label[contains(@title,'Search')]/../..//input");
	private static final By firstInstrument = new By.ByXPath(selectInstrument +
			"div[contains(@data-t,'options')]/div[contains(@data-t,'option')]");
	private static final By rightDirectionButton = new By.ByXPath(selectInstrument + "span[contains(@aria-label,'right')]/..");
	private static final By confirmButton = new By.ByXPath(selectInstrument + "button[contains(@type,'submit')]");
	private static final By cryptoView = new By.ByXPath(orderBookInXpath + "button[contains(text(),'Crypto view')]");
	private static final By classicView = new By.ByXPath(orderBookInXpath + "button[contains(text(),'Classic view')]");
	private static final By goToCenter = new By.ByXPath(orderBookInXpath + "span[contains(text(),'Go to center')]");
	private static final By increasePrecision = new By.ByXPath(orderBookInXpath +
			"div[contains(@class, 'Footer')]//button[contains(text(),'-')]");
	private static final By decreasePrecision = new By.ByXPath(orderBookInXpath +
			"div[contains(@class, 'Footer')]//button[contains(text(),'+')]");

	public OrderBookBox(WebDriver drv) {
		super(drv);
		driver=drv;
	}

	protected void clearOrderBookTabs() {
		while (driver.findElements(closeTab).size() > 0) {
			click(closeTab);
			click(confirmTabRemoval);
		}
	}
	protected void addFirstInstrument() {
		clearOrderBookTabs();
	}

}
