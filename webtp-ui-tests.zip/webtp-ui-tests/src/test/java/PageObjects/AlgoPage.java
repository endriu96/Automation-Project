package PageObjects;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class AlgoPage {

    protected WebDriver driver;
    private int MAXWAIT = 10000;
    private int WAITTICKSIZE = 100;
    protected Actions action ;

    public AlgoPage(WebDriver driver){
        this.driver =driver;
        action = new Actions(driver);
    }
    protected void click(By element){
        waitFor(element);
        driver.findElement(element).click();
    }

    protected  void doubleClick(By element) throws InterruptedException {
        waitFor(element);
        driver.findElement(element).click();
        driver.findElement(element).click();
   //     action.doubleClick();
    }

    protected void typeIn (String input, By element){
        waitFor(element);
        driver.findElement(element).sendKeys(Keys.chord(Keys.LEFT_CONTROL, "a"));
        driver.findElement(element).sendKeys(Keys.DELETE);
        driver.findElement(element).sendKeys(input);
    }
    protected boolean isPresent(By element){
    	return (driver.findElements(element).size()>0);
    }

    protected void hoverOver(By element){
        action.moveToElement(driver.findElement(element)).moveToElement(driver.findElement(element));
    }
    protected void verifyPresence(By element){
		  Assertions.assertTrue(isPresent(element), "Element "+element.toString() +"not found");
	}

    protected void waitFor(By element){
        int wait=MAXWAIT;
        if (driver.findElements(element).isEmpty())
        while (driver.findElements(element).size()<1 && wait >0)
        {
            try {
                Thread.sleep(WAITTICKSIZE);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            wait-=WAITTICKSIZE;
        }
        verifyPresence(element);
    }
}
