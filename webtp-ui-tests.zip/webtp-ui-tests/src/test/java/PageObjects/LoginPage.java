package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private static By loginField = new By.ById("username");
    private static By passwordField = new By.ById("password");
    private static By loginButton = new By.ByCssSelector("#root button");
    private WebDriver obj;

    public LoginPage(WebDriver driver){
        obj=driver;
    }
    void click(By selector){
        obj.findElement(selector).click();
    }
    void fill (By selector, String content){
        obj.findElement(selector).clear();
        obj.findElement(selector).sendKeys(content);
    }

    public void login (String username, String password){
        fill(loginField, username);
        fill(passwordField, password);
        click(loginButton);
    }
}
