package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class InstrumentPicker extends AlgoPage {

    private static final By instrumentSearchInput= new By.ByXPath("//header[@class='window-header']/div[contains(@class, 'title')]" +
            "[contains(text(),'Select instruments')]/../..//input[@type='text']");
    private static final By availableInstrumentListFirstItem = new By.ByXPath("//div[@data-testid=\"available-instruments\"]//" +
            "div[@data-t='options']/div[@data-t=\"option\"][1]");
    private static final By selectedInstrumentListFirstItem = new By.ByXPath("//div[@data-testid=\"selected-instruments\"]" +
            "//div[@data-t='options']/div[@data-t=\"option\"][1]");
    private static final By moveInstrumentButton = new By.ByXPath("//header" +
            "[@class='window-header']/div[contains(@class, 'title')][contains(text(),'Select instruments')]" +
            "/../..//button[@type=\"button\"]/span[@aria-label=\"right\"]");
    private static final By confirmButton = new By.ByXPath("//header[@class='window-header']/div[contains(@class, 'title')]" +
            "[contains(text(),'Select instruments')]/../..//button[@type=\"submit\"]");


    public InstrumentPicker(WebDriver driver) {
        super(driver);

    }

    public void chooseInstrument(String instrumentName) throws InterruptedException {
        typeIn(instrumentName, instrumentSearchInput);
        click(availableInstrumentListFirstItem);
        click(moveInstrumentButton);
        waitFor(selectedInstrumentListFirstItem);
    }

    public void confirm(){
        click(confirmButton);
    }

}
//header[@class='window-header']/div[contains(@class, 'title')][contains(text(),'Select instruments')]/../..//button[@type=\"button\"]