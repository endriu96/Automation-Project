import PageObjects.GeneralPage;
import PageObjects.LoginPage;
import PageObjects.StrategyPopUps.AdvancedMarketMakingPopUp;
import PageObjects.UniversalObjects;
import TestDefinitions.AdvancedMarketMaking;
import TestDefinitions.GeneralActions;
import TestDefinitions.OrderBook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


class Main {
	 private WebDriver driver;
	    private GeneralPage onTheDashboard;
	    private LoginPage onTheLoginPage;
	    private UniversalObjects inTheMenu;
	    private GeneralActions pageTests;
	    private AdvancedMarketMaking amm;
	    private OrderBook orderBook;
	    private AdvancedMarketMakingPopUp ammPopUp;

	    /*To do: Add @BeforeAll with logging into admin panel, making sure if dedicated automated tests user
	    * is in the system and if not creating such user with required access rights.
	    * This user should be used later to log in as for the automated tests.
	    * */
	    @BeforeEach
	    void initAndLogin(){

	        System.setProperty("webdriver.chrome.driver", "driver\\chromedriver.exe");
	        driver = new ChromeDriver();
	        driver.get("https://192.168.1.163/tradepad/#/login");
	        driver.manage().window().maximize();
			shortWait();
	        driver.findElement(By.id("details-button")).click();
	        driver.findElement(By.id("proceed-link")).click();
			shortWait();
	        onTheLoginPage = new LoginPage(driver);
	        inTheMenu = new UniversalObjects(driver);
	        pageTests = new GeneralActions(driver);
	        amm = new AdvancedMarketMaking(driver);
	        orderBook = new OrderBook(driver);
	        onTheLoginPage.login("test1","LU'r&FKU?Q7Na3%4");
			shortWait();
	        inTheMenu.makeSureDefaultWorkspaceExists();

	    }
	    @AfterEach
	    void shutdown()
	    {
			inTheMenu.switchToDefaultWorkspace();
			inTheMenu.removeNonActiveWorkspaces();
	        inTheMenu.logout();
	        driver.quit();
	    }

    @Test
    public void presenceOfUniversalObjects() {
	    	inTheMenu.checkPresenceOfUniversallyPresentObjects();
    }
    @Test// Need fixing. Test is failing at removing boxes due to a bug in WebTp. When fixed this test will be fixable
    public void addNewBoxes() {
	    pageTests.addNewBoxes();
    }

    @Test
    public void addAndMoveToDashboard() {
        inTheMenu.createDashboardAndMoveToIt("addAndMoveToDashboard");
    }
    @Test
    public void runAMM() throws InterruptedException {
	    amm.runAMM();
    }
    @Test
	public void addAndRemoveOrder() {
		orderBook.addAndRemoveOrder();
	}
	private void shortWait()
	{
		try {Thread.sleep(500);}  catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
